# CSP Six Week Activity Log Website

This is a static website made with HTML, CSS and JavaScript. The home page shows six week cards. Selecting a week displays its six-day activity log in a table.

## Preview on your computer
1. Extract the ZIP file.
2. Open the `index.html` file in Chrome, Edge or another browser.

## Publish using GitHub Pages
1. Sign in to GitHub and create a new repository (for example, `csp-activity-log`).
2. Upload `index.html`, `style.css`, and `script.js` to the repository's main/root folder.
3. Open the repository's **Settings**.
4. Select **Pages** from the left menu.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to publish the website. The Pages section will show your website link.

The activity wording is based on the six week images supplied in the conversation. The signature column is left blank for signing.
