const weeks = [
  {
    title: "Activity Log for the First Week",
    rows: [
      ["Day-1", "Knowing about the CSP Project, Studied the guidelines of the CSP and Discussing about the selected topic.", "Understand the importance of CSP in the curriculum, got clear idea"],
      ["Day-2", "We team members planned about all the activities to be done as part of the project", "Discussion about various aspects of the topic lead to clear ideas"],
      ["Day-3", "We explored the area and selected the locality to conduct the project", "Exploring the area made us socialize and learn about locality"],
      ["Day-4", "As part of the project, We prepared all the required and suggested documents for beginning the project", "Understood all the permissions required for the project"],
      ["Day-5", "All the members visited the Sachivalayam of the selected locality and got the signatures done", "Talked to respected officer for the permissions"],
      ["Day-6", "We submitted permission letter and documents at the college to begin the project", "Got accurate guidelines from the provided guide and HOD"]
    ]
  },
  {
    title: "Activity Log for the Second Week",
    rows: [
      ["Day-1", "On the first day, we know the demographic and basic information", "We get to know about the basic details of plants like their breed and their uses"],
      ["Day-2", "We get some knowledge about plants and varieties", "We get to know about their types and species and how we should treat them"],
      ["Day-3", "What should plants consume and what products", "We get to know about the products, what consumes plants"],
      ["Day-4", "We get some knowledge about How plants are used in bio diversity", "we got information from the farmers how plants are useful to bio diversity"],
      ["Day-5", "We visited the farms of plants and got some knowledge how we should treat them", "We got information from the farmers about their farms and their treatment"],
      ["Day-6", "We give some feedback to the farmers, and also we got some ideas about the plants", "We have knowledge about the plants and their properties and plantation methods"]
    ]
  },
  {
    title: "Activity Log for the Third Week",
    rows: [
      ["Day-1", "On the first day, we know the demographic and basic information", "We get to know about the basic details of flowering plants"],
      ["Day-2", "We get some knowledge about flowering and varieties", "We get to know about their breeds, and types, maintenance"],
      ["Day-3", "What should flowering plants consume", "We get to know about flowering plants consume properties"],
      ["Day-4", "We get some knowledge flowering plants", "we got information from the public and nursery farmers"],
      ["Day-5", "We visited the nursery shop to observe the different types and get some information", "We got information about different types of flowering plants"],
      ["Day-6", "We learn how to treat plants and also we got some ideas about the plants", "We have knowledge about their properties and plants consume composition"]
    ]
  },
  {
    title: "Activity Log for the Fourth Week",
    rows: [
      ["Day-1", "On the first day, we know the demographic and basic information", "We get to know about the basic details for plants their environmental factors"],
      ["Day-2", "We get some knowledge about environmental affects on plants", "We get to know about how plants effect on environmental conditions"],
      ["Day-3", "Which factors are suitable for plants to grow properly", "We get to know about the factors and how they grow up effectively"],
      ["Day-4", "We get some knowledge about how plants behave on climatic conditions", "we got information from the nursery farmers about suitable climatic conditions for plants"],
      ["Day-5", "We visited the nursery farmers learn about the some species and factors environmentals factor", "We got information from the nursery farmers about some species and effect by environmental factors"],
      ["Day-6", "We give some feedback to the farmers, and also we got some ideas about the plants and environmental effects", "We have knowledge about the plants and their environmental effects"]
    ]
  },
  {
    title: "Activity Log for the Fifth Week",
    rows: [
      ["Day-1", "On the first day, we know the demographic and basic information", "We get to know about the basic details of plants and plants genetics"],
      ["Day-2", "We get some knowledge about plant genetics", "We get to know about their plants genetics and morphology"],
      ["Day-3", "Types of plants and its types of mutations", "We get to know about the types of plants and mutations"],
      ["Day-4", "We get some knowledge about plant mutation and genetics", "we got information from the nursery farmers about the plants mutations and genetics"],
      ["Day-5", "We visited the nearest nursery farming area know about some plant genetics", "We got information from the nursery farming area about some types of plants genetics and mutations"],
      ["Day-6", "We give some ideas to the nursery farmers about the plant genetics and genetics", "We have knowledge about the various types of plants and its mutation and genetics"]
    ]
  },
  {
    title: "Activity Log for the Sixth Week",
    rows: [
      ["Day-1", "As part of the last week of we know about endangered plant species and list out them and also give some measures to the nursery farmers", "We get to know about the endangered plants on our earth"],
      ["Day-2", "We got some knowledge about endangered plants", "We get to know about types of endangered plant species"],
      ["Day-3", "What should do for plants which are endangred situation", "We get to know about the endangered plant species what we do measures for them"],
      ["Day-4", "We get some knowledge about that plant species and conditions", "we got information from the near nursery and ask farmers about it"],
      ["Day-5", "We get some knowledge how we treat treated plant species", "Our doubts are clarified by nursery farmers and nursery incharge"],
      ["Day-6", "Finally we understand about the endangered plant species and list out them", "We got some knowledge on endangered plant species and take measures for them"]
    ]
  }
];

const weekGrid = document.getElementById("weekGrid");
const panel = document.getElementById("activityPanel");
const title = document.getElementById("weekTitle");
const rows = document.getElementById("activityRows");

weeks.forEach((week, index) => {
  const button = document.createElement("button");
  button.className = "week-card";
  button.type = "button";
  button.innerHTML = `
    <span class="week-number">${String(index + 1).padStart(2, "0")}</span>
    <span class="week-copy"><strong>Week ${index + 1}</strong><span>View six days of activities</span></span>
    <span class="arrow" aria-hidden="true">›</span>`;
  button.addEventListener("click", () => showWeek(index));
  weekGrid.appendChild(button);
});

function showWeek(index) {
  const week = weeks[index];
  title.textContent = week.title;
  rows.replaceChildren();
  week.rows.forEach((entry) => {
    const tr = document.createElement("tr");
    entry.forEach((value) => {
      const td = document.createElement("td");
      td.textContent = value;
      tr.appendChild(td);
    });
    const signature = document.createElement("td");
    signature.className = "signature-cell";
    signature.setAttribute("aria-label", "Person in-charge signature space");
    tr.appendChild(signature);
    rows.appendChild(tr);
  });
  panel.hidden = false;
  panel.scrollIntoView({ behavior: "smooth", block: "start" });
}
document.getElementById("backButton").addEventListener("click", () => {
  panel.hidden = true;
  document.getElementById("weeks-heading").scrollIntoView({ behavior: "smooth" });
});
